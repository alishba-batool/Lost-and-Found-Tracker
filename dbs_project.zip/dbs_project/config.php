<?php
$serverName = "localhost\\SQLEXPRESS"; // Update if your SQL Server instance differs
$connectionOptions = array(
    "Database" => "PROJECCT",
    "Uid" => "", // Update if using a different SQL Server login
    "PWD" => "" // Update with your SQL Server password
);

$conn = sqlsrv_connect($serverName, $connectionOptions);
if ($conn === false) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . print_r(sqlsrv_errors(), true)]));
}
?>