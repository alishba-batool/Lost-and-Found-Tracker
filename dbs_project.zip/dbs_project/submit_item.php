<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        error_log("POST data: " . print_r($_POST, true));

        $item_name = filter_input(INPUT_POST, 'itemName', FILTER_DEFAULT);
        $description = filter_input(INPUT_POST, 'description', FILTER_DEFAULT);
        $category_name = filter_input(INPUT_POST, 'category', FILTER_DEFAULT);
        $location_name = filter_input(INPUT_POST, 'location', FILTER_DEFAULT);
        $status = filter_input(INPUT_POST, 'status', FILTER_DEFAULT);

        error_log("Filtered data: item_name=$item_name, description=$description, category_name=$category_name, location_name=$location_name, status=$status");

        if ($item_name === null || $description === null || $category_name === null || $location_name === null || $status === null) {
            error_log("One or more fields are null");
            echo json_encode(["status" => "error", "message" => "Invalid or missing form data."]);
            exit;
        }

        if (empty($item_name) || empty($description) || empty($category_name) || empty($location_name) || empty($status)) {
            error_log("Validation failed: Empty fields");
            echo json_encode(["status" => "error", "message" => "All fields are required."]);
            exit;
        }

        // Get category_id
        $sql_category = "SELECT category_id FROM Category WHERE name = ?";
        $params_category = array($category_name);
        $stmt_category = sqlsrv_query($conn, $sql_category, $params_category);
        if ($stmt_category === false) {
            error_log("Category query failed: " . print_r(sqlsrv_errors(), true));
            throw new Exception("Database error (category): " . print_r(sqlsrv_errors(), true));
        }
        $category = sqlsrv_fetch_array($stmt_category, SQLSRV_FETCH_ASSOC);
        $category_id = $category ? $category['category_id'] : null;
        error_log("category_id=$category_id");

        // Get location_id
        $sql_location = "SELECT location_id FROM Location WHERE name = ?";
        $params_location = array($location_name);
        $stmt_location = sqlsrv_query($conn, $sql_location, $params_location);
        if ($stmt_location === false) {
            error_log("Location query failed: " . print_r(sqlsrv_errors(), true));
            throw new Exception("Database error (location): " . print_r(sqlsrv_errors(), true));
        }
        $location = sqlsrv_fetch_array($stmt_location, SQLSRV_FETCH_ASSOC);
        $location_id = $location ? $location['location_id'] : null;
        error_log("location_id=$location_id");

        if (!$category_id || !$location_id) {
            error_log("Invalid category or location: category_id=$category_id, location_id=$location_id");
            echo json_encode(["status" => "error", "message" => "Invalid category or location."]);
            exit;
        }

        $reported_by = 1; // Hardcoded for now; replace with session user ID later
        error_log("Inserting item with reported_by=$reported_by");

        $sql = "INSERT INTO Item (reported_by, category_id, location_id, item_name, description, status, date_reported)
                VALUES (?, ?, ?, ?, ?, ?, GETDATE())";
        $params = array($reported_by, $category_id, $location_id, $item_name, $description, $status);
        $stmt = sqlsrv_query($conn, $sql, $params);

        if ($stmt === false) {
            error_log("Insert failed: " . print_r(sqlsrv_errors(), true));
            throw new Exception("Insert failed: " . print_r(sqlsrv_errors(), true));
        }

        error_log("Item inserted successfully");
        echo json_encode(["status" => "success", "message" => "Item reported successfully!"]);
    }
} catch (Exception $e) {
    error_log("Exception: " . $e->getMessage());
    echo json_encode(["status" => "error", "message" => "An error occurred: " . $e->getMessage()]);
} finally {
    if (isset($stmt) && $stmt) sqlsrv_free_stmt($stmt);
    if (isset($conn)) sqlsrv_close($conn);
}
?>