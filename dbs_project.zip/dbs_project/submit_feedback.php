<?php
header('Content-Type: application/json');
include 'config.php';

// Validate input
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : null;
$item_id = isset($_POST['item_id']) ? intval($_POST['item_id']) : null;
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : null;
$comments = isset($_POST['comments']) ? trim($_POST['comments']) : null;

if (!$user_id || !$item_id || !$rating || !$comments) {
    echo json_encode([
        "status" => "error",
        "message" => "All fields are required."
    ]);
    exit;
}

// Insert feedback into the database
$sql = "INSERT INTO feedback (user_id, item_id, rating, comments) VALUES (?, ?, ?, ?)";
$params = [$user_id, $item_id, $rating, $comments];
$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    echo json_encode([
        "status" => "error",
        "message" => "Failed to submit feedback: " . print_r(sqlsrv_errors(), true)
    ]);
    exit;
}

echo json_encode([
    "status" => "success",
    "message" => "Thank you for your feedback!"
]);
?>