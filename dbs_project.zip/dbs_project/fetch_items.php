<?php
header('Content-Type: application/json');
require_once 'config.php';

try {
    $sql = "SELECT i.item_id, i.item_name, i.description, i.status, i.date_reported, c.name AS category, l.name AS location
            FROM Item i
            JOIN Category c ON i.category_id = c.category_id
            JOIN Location l ON i.location_id = l.location_id
            WHERE i.status IN ('Lost', 'Found')";
    $stmt = sqlsrv_query($conn, $sql);

    if ($stmt === false) {
        throw new Exception("Query failed: " . print_r(sqlsrv_errors(), true));
    }

    $items = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $items[] = [
            'item_id' => $row['item_id'],
            'item_name' => $row['item_name'],
            'description' => $row['description'],
            'status' => $row['status'],
            'date_reported' => $row['date_reported'] ? $row['date_reported']->format('Y-m-d') : '',
            'category' => $row['category'],
            'location' => $row['location']
        ];
    }

    echo json_encode(["status" => "success", "items" => $items]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "An error occurred: " . $e->getMessage()]);
} finally {
    if (isset($stmt) && $stmt) sqlsrv_free_stmt($stmt);
    if (isset($conn)) sqlsrv_close($conn);
}
?>