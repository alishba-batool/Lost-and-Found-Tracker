<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $item_id = filter_input(INPUT_POST, 'itemID', FILTER_VALIDATE_INT);
        $claimant_name = trim($_POST['claimantName'] ?? '');
        $contact_email = filter_input(INPUT_POST, 'contactEmail', FILTER_VALIDATE_EMAIL);
        $claim_details = trim($_POST['claimDetails'] ?? '');

        if (!$item_id || !$claimant_name || !$contact_email || !$claim_details) {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "All fields are required and must be valid."]);
            exit;
        }

        // Check if item exists
        $sql_check = "SELECT COUNT(*) FROM Item WHERE item_id = ?";
        $params_check = array($item_id);
        $stmt_check = sqlsrv_query($conn, $sql_check, $params_check);
        $count = sqlsrv_fetch_array($stmt_check, SQLSRV_FETCH_NUM)[0];
        if ($count == 0) {
            echo json_encode(["status" => "error", "message" => "Item ID not found."]);
            exit;
        }

        $claimed_by = 1; // Hardcoded for now; replace with session user ID later

        $sql = "INSERT INTO Claim (
                    claim_id, item_id, claimed_by, claimed_date, verification_status,
                    claimant_name, contact_email, claim_details
                )
                VALUES (
                    (SELECT ISNULL(MAX(claim_id), 0) + 1 FROM Claim), ?, ?, GETDATE(), 'Pending',
                    ?, ?, ?
                )";
        $params = array($item_id, $claimed_by, $claimant_name, $contact_email, $claim_details);
        $stmt = sqlsrv_query($conn, $sql, $params);

        if ($stmt === false) {
            $sqlsrv_error = print_r(sqlsrv_errors(), true);
            echo json_encode([
                "status" => "error",
                "message" => "Insert failed.",
                "sqlsrv_error" => $sqlsrv_error
            ]);
            exit;
        }

        echo json_encode(["status" => "success", "message" => "Claim submitted successfully!"]);
    }
} catch (Exception $e) {
    echo json_encode([
        "status" => "error",
        "message" => "An error occurred: " . $e->getMessage(),
        "exception" => $e instanceof Exception ? $e->getTraceAsString() : null
    ]);
} finally {
    if (isset($stmt_check) && $stmt_check) sqlsrv_free_stmt($stmt_check);
    if (isset($stmt) && $stmt) sqlsrv_free_stmt($stmt);
    if (isset($conn)) sqlsrv_close($conn);
}
?>