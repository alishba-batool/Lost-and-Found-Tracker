<?php
require_once 'config.php';
echo "Connected!";
?>