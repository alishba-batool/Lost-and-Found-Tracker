
DROP TABLE IF EXISTS Feedback;
DROP TABLE IF EXISTS AdminAction;
DROP TABLE IF EXISTS Claim;
DROP TABLE IF EXISTS StatusLog;
DROP TABLE IF EXISTS Item;
DROP TABLE IF EXISTS Location;
DROP TABLE IF EXISTS Category;
DROP TABLE IF EXISTS Users;
drop database PROJECCT

CREATE DATABASE PROJECCT; 
USE PROJECCT;

CREATE TABLE Users (
    user_id INT identity  PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(20) CHECK (role IN ('user', 'admin'))
);

CREATE TABLE Category (
    category_id INT identity PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE Location (
    location_id INT identity PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE Item (
    item_id INT identity PRIMARY KEY,
     reported_by INT
	 FOREIGN KEY REFERENCES Users(user_id),
    category_id INT
	FOREIGN KEY REFERENCES Category(category_id),
    location_id INT
	FOREIGN KEY REFERENCES Location(location_id),
    item_name VARCHAR(100) NOT NULL,
    description TEXT,
    status VARCHAR(50) CHECK (status IN ('Lost', 'Found', 'Claimed')) DEFAULT 'Lost',
    date_reported DATE DEFAULT GETDATE()
);

CREATE TABLE Claim (
    claim_id INT identity PRIMARY KEY,
    item_id INT
	FOREIGN KEY REFERENCES Item(item_id),
    claimed_by INT
	FOREIGN KEY REFERENCES Users(user_id),
    claimed_date DATE DEFAULT GETDATE(),
    verification_status VARCHAR(50) DEFAULT 'Pending'
);

CREATE TABLE AdminAction (
    action_id INT identity PRIMARY KEY,
  claim_id INT FOREIGN KEY REFERENCES Claim(claim_id),
    admin_id INT FOREIGN KEY REFERENCES Users(user_id),
    action_taken TEXT,
    action_date DATE DEFAULT GETDATE()
);

CREATE TABLE StatusLog (
    log_id INT identity PRIMARY KEY,
    item_id INT FOREIGN KEY REFERENCES Item(item_id),
    old_status VARCHAR(50),
    new_status VARCHAR(50),
    changed_date DATE DEFAULT GETDATE()
);

CREATE TABLE Feedback (
    feedback_id INT identity PRIMARY KEY,
   user_id INT FOREIGN KEY REFERENCES Users(user_id),
    item_id INT FOREIGN KEY REFERENCES Item(item_id),
    rating INT CHECK (rating BETWEEN 1 AND 5),
    comments TEXT,
    feedback_date DATE DEFAULT GETDATE()
);


INSERT INTO Users (name, email, password, role) VALUES
('Alishba Batool', 'alishba@example.com', 'pass123', 'user'),
('Zainab Noor', 'zainab@example.com', 'pass456', 'user'),
('Admin User', 'admin@example.com', 'adminpass', 'admin');
SELECT *FROM Users;

INSERT INTO Category (name)
VALUES ('Electronics'),
('Books'),
('Stationery'),
('Accessories');
SELECT *FROM Category;

INSERT INTO Location (name)
VALUES ('Library'),
('Cafeteria'),
('AUDITORIUM'), 
('IT LAB');
SELECT *FROM Location;

INSERT INTO Item (reported_by, category_id, location_id, item_name, description, status)
VALUES
(1, 1, 4, 'USB Drive', 'Black 32GB USB found near lab.', 'Found'),
(2, 4, 2, 'Wallet', 'Brown leather wallet lost in cafeteria.', 'Lost');
 
SELECT *FROM Item;

INSERT INTO Feedback (user_id, item_id, rating, comments, feedback_date)
VALUES 
(1, 2, 5, 'Great service, found my lost wallet quickly!', '2025-06-13'),
(2, 4, 4, 'Helpful staff, but took some time to verify my claim.', '2025-06-12');

SELECT *FROM Feedback;

SELECT i.item_id, i.item_name, u.name AS reported_by, l.name AS location
FROM Item i
JOIN Users u ON i.reported_by = u.user_id
JOIN Location l ON i.location_id = l.location_id
WHERE i.status = 'Lost';


CREATE VIEW View_LostItems AS
SELECT item_name, description, date_reported FROM Item WHERE status = 'Lost';

SELECT * FROM View_LostItems

SELECT c.name AS category, COUNT(*) AS total_items
FROM Item i
JOIN Category c ON i.category_id = c.category_id
GROUP BY c.name;

BEGIN TRANSACTION;
    UPDATE Item SET status = 'Claimed' WHERE item_id = 2;
	UPDATE Item SET status = 'Claimed' WHERE item_id = 3;
    INSERT INTO StatusLog (item_id, old_status, new_status) 
	VALUES (2, 'Lost', 'Claimed'),
	(3,'Lost','Claimed');
COMMIT;

SELECT *FROM StatusLog;
SELECT * FROM Item;

SELECT user_id, item_id, rating, comments
FROM Feedback
ORDER BY feedback_date DESC;

