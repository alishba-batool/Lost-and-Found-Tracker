<?php
header('Content-Type: application/json');
include 'config.php';

// Query to fetch feedback
$sql = "SELECT user_id, item_id, rating, comments FROM feedback";
$stmt = sqlsrv_query($conn, $sql);

if ($stmt === false) {
    echo json_encode([
        "status" => "error",
        "message" => "Query failed: " . print_r(sqlsrv_errors(), true)
    ]);
    exit;
}

$feedback = [];
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $feedback[] = [
        "user_id" => $row['user_id'],
        "item_id" => $row['item_id'],
        "rating" => $row['rating'],
        "comments" => $row['comments']
    ];
}

echo json_encode([
    "status" => "success",
    "data" => $feedback
]);
?>